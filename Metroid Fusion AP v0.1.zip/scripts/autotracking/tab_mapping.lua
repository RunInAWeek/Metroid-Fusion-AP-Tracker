TAB_MAPPING = {  

    [''] = 'Main Deck',    
    [''] = 'Sector 1',
    [''] = 'Sector 2',
    [''] = 'Sector 3',
    [''] = 'Sector 4',
    [''] = 'Sector 5',
    [''] = 'Sector 6',

} 